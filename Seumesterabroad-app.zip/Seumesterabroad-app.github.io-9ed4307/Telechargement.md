layout: page
title: "Telechargement"
permalink: /https://seumesterabroad.github.io/app.github.io/gh-pages/Telechargement.md/

## Instructions de telechargement
#### Pour les utilisateurs de windows: " lien de telechargement"
Télechargez l'éxécutable en cliquant sur le lien ci-dessus. Executez le fichier télécharger. Lancez le logiciel.

#### Pour les utilisateurs de linux: "lien de telechargement"
Telechargez l'archive en cliquant sur le lien ci-dessus. Décompressez l'archive. Executer le fichier "nom du fichier" dans le dossier extrait.

#### Pour les utilisateurs de Mac: "lien de telechargement"
Telechargez l'archive en cliquant sur le lien ci-dessus. Décompressez l'archive. Executer le fichier "nom du fichier" dans le dossier extrait.

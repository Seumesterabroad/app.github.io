#ifndef MAIN_H
#define MAIN_H

#include "graph.h"
#include "graph_processing.h"
#include "client/print_page.h"
#include "construction.h"
#include <gtk/gtk.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>




#endif

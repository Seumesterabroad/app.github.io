#include "graph.h"


#ifndef CONSTRUCTION_H_
#define CONSTRUCTION_H_

SDL_Surface* create(size_t num_vertices,graph_p G);

#endif